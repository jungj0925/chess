#include "observer.h"

Observer::~Observer() {}

